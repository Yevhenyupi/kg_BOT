---
name: Feature request
about: Request a new feature
---

Describe whatever you want to be implemented in future:


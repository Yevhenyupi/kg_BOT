---
name: Bug report
about: Create a new bug report ticket
---

Project version: 
Platform (Windows, Linux, etc.): 
Python version: 
OS version: 

Problem details:



<!--
Don't forget to include debug logs to this ticket if needed.
-->

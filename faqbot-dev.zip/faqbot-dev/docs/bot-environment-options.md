# List of environment options

Available environment options:

  * `APIKEY` - API token from [@BotFather](https://t.me/BotFather);
  * `LOGLEVEL` - specify current logging level. If not set `INFO` will be used;
  * `CFGPATH` - override the default directory for configuration files;
  * `DATAPATH` - override the default directory for data files.
